'use client'
import Link from 'next/link';
import { useState, useEffect } from 'react';
import Layout from '@/app/components/Layout';
const CartPage = () => {
  const [cart, setCart] = useState({});

  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    setCart(savedCart ? JSON.parse(savedCart) : {});
  }, []);

  const removeFromCart = (productId) => {
    const newCart = {...cart};
    delete newCart[productId];
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const changeQuantity = (productId, quantity) => {
    const newCart = {...cart};
    if (newCart[productId]) {
      newCart[productId].quantity = quantity;
    }
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };
  const shippingCost = 6; // يمكنك تعديل هذا الرقم بناءً على سياسة الشحن لديك

  const totalPrice = () => {
    return Object.values(cart).reduce((acc, { price, quantity }) => acc + price * quantity, 0);
  };
  const totalPriceWhithSipp = () => {
    const totalProductsPrice = Object.values(cart).reduce((acc, { price, quantity }) => acc + price * quantity, 0);
    return totalProductsPrice + shippingCost;
  };
  
  return (
   
       <Layout>
<main className="container mx-auto p-4 flex flex-wrap md:flex-nowrap">
      <div className="flex-1 md:flex-2/3">
  

        {Object.keys(cart).length === 0 ? (
          <div className="text-center text-gray-500">Your cart is empty.</div>
        ) : (
          Object.keys(cart).map((key) => (
            <div key={key} className="mx-0 my-2 flex overflow-hidden rounded-xl border border-gray-400 bg-white md:mx-4">
                
                <div className="flex items-center justify-center border-l border-gray-400" style={{ minWidth: '120px' }}>

                <img
                  alt={`Image of ${cart[key].title}`}
                  src={cart[key].imagePaths[0]}  // تعديل هنا لاستخدام الصورة الأولى من imagePaths
                  className="object-contain p-5"
                />
              </div>

              
              <div className="relative mx-4 my-2.5 flex grow flex-wrap items-center justify-between lg:my-8 lg:flex-nowrap">
                <span className="max-w-full grow transition-colors hover:text-primary md:max-w-xs lg:px-5">{cart[key].title}</span>
                <div className="order-last mt-3 flex items-center justify-center text-center lg:order-none lg:mt-0">
                  <button
                    className="h-8 w-8 rounded-full border border-primary text-xl text-primary hover:bg-primary hover:text-white"
                    onClick={() => changeQuantity(key, cart[key].quantity + 1)}
                  >
                    +
                  </button>
                  <input
                    className="mx-1 h-8 w-14 rounded-2xl border border-gray-600 text-center outline-none"
                    type="number"
                    min="1"
                    value={cart[key].quantity}
                    onChange={(e) => changeQuantity(key, parseInt(e.target.value))}
                  />
                  <button
                    className="h-8 w-8 rounded-full border border-primary text-xl text-primary hover:bg-primary hover:text-white"
                    onClick={() => changeQuantity(key, cart[key].quantity - 1)}
                    disabled={cart[key].quantity <= 1}
                  >
                    -
                  </button>
                </div>
                <span className="order-last mt-3 flex items-center justify-center text-center lg:order-none lg:mt-0">{cart[key].price * cart[key].quantity} د.ع</span>
                <button
                  className="order-last mt-3 flex items-center justify-center text-center lg:order-none lg:mt-0"
                  onClick={() => removeFromCart(key)}
                >
              حذف
                </button>
              </div>
            </div>
          ))
        )}
      </div>
   
      <div className="flex-1 md:flex-1/3">
      <div className="mx-0 my-2 overflow-hidden rounded-xl border border-gray-400 bg-white px-4 py-6 md:mx-4">
        <div className="my-4 flex justify-between">
          <span className="text-gray-800">المجموع</span>
          <span className="font-bold">{totalPrice()} د.ع</span>
        </div>
        <div className="my-4 flex justify-between">
          <span className="text-gray-800">الشحن</span>
          <span className="flex items-center font-bold">6 د.ع</span>
        </div>
        <hr className="my-5 border-gray-500" />
        <div className="my-4 flex justify-between">
          <span className="text-lg font-bold text-gray-800">الإجمالي</span>
          <span className="text-lg font-bold">{totalPriceWhithSipp()} د.ع</span>
        </div>
        <Link href="/ar/product/%d9%85%d9%83%d9%86%d8%b3%d8%a9-%d8%a8%d9%8a%d8%b3%d9%8a%d9%84-%d9%84%d8%ba%d8%b3%d9%8a%d9%84-%d8%a7%d9%84%d8%b3%d8%ac%d8%a7%d8%af-%d9%88%d8%a7%d9%84%d9%81%d8%b1%d8%b4-%d8%a8%d8%a7%d9%84%d8%a8%d8%ae/">
          <button className="flex items-center justify-center font-bold focus:outline-none px-16 py-2 text-lg rounded leading-loose text-button-secondary bg-secondary hover:bg-secondary-hover border-solid border border-secondary-washed-out transition duration-200 ease-in-out disabled:text-primary-300 mb-2 mt-8 w-full">
            متابعة التسوق
          </button>
        </Link>
        <Link href="/ar/checkout/">
          <button className="flex items-center justify-center font-bold focus:outline-none px-16 py-2 text-lg rounded leading-loose text-button bg-primary hover:bg-primary-hover transition duration-200 ease-in-out disabled:text-accent-disabled disabled:bg-accent-hover w-full">
            أكمل الشراء
          </button>
        </Link>
      </div>
    </div>
    </main>
       </Layout>
    
  );
};

export default CartPage;
