// في ملف صفحة، مثلاً pages/index.tsx
import Layout from '@/app/components/Layout';
import HeroSection from './components/HeroSection';
import Slide from './components/slide';
import ProductSlider from './components/GalleryVertical';
import HomePage1 from './Home/page';

const HomePage = () => (
  <HomePage1></HomePage1>
);

export default HomePage;
