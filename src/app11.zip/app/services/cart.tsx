export const addToCart = (product: { id: any; }, quantity = 1) => {
    let cart = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')) : {};
    let id = product.id;
  
    if (cart[id]) {
      cart[id].quantity += quantity;
    } else {
      cart[id] = {
        ...product,
        quantity: quantity
      };
    }
  
    localStorage.setItem('cart', JSON.stringify(cart));

    console.log( JSON.stringify(cart))
  }
  