import React from 'react';
import Image from 'next/image'; // استيراد مكتبة Image من next/image
import { SfButton, SfIconFavorite, SfLink } from '@storefront-ui/react';

const ProductCard = ({ product }) => {
  // تحويل البيانات إلى الصيغة المطلوبة
  const transformedProduct = {
    id: product.id.toString(),
    name: product.title,
    price: `د.ع ${product.price.toFixed(2)}`,
    handle: product.handle,
    img: {
      src: product.image,
      alt: product.description,  
    }
  };
  
  return (
    <div className="product-card first:ms-auto last:me-auto ring-1 ring-inset ring-neutral-200 shrink-0 rounded-md hover:shadow-lg lg:w-[25vw]">
    <div className="relative">
      <SfLink href={"product/" +transformedProduct.handle} className="block">
        {/* استخدام مكتبة Image */}
        <Image
  src={transformedProduct.img.src}
  alt={transformedProduct.img.alt}
  className="block object-cover h-auto rounded-md aspect-square lg:w-[90%] lg:h-[90%]"
  width={146}
  height={146}
/>

      </SfLink>
      <SfButton
        variant="tertiary"
        size="sm"
        square
        className="absolute bottom-0 right-0 mr-2 mb-2 bg-white border border-neutral-200 !rounded-full"
        aria-label="Add to wishlist"
      >
        <SfIconFavorite size="sm" />
      </SfButton>
    </div>
    <div className="p-2 border-t border-neutral-200 typography-text-sm">
      <SfLink  href={"product/" +transformedProduct.handle} variant="secondary" className="no-underline productName">
        {transformedProduct.name}
      </SfLink>
      <span className="block mt-2 font-bold" style={{ color: '#fe4960' }}>
        {transformedProduct.price}
      </span>
    </div>
  </div>
  
  );
};

export default ProductCard;
