import { useEffect, useState } from "react";

const Cart = () => {
    const [cart, setCart] = useState({});
  
    useEffect(() => {
      setCart(JSON.parse(localStorage.getItem('cart')));
    }, []);
  
    return (
      <div>
        <h2>Cart</h2>
        {Object.keys(cart).map((key) => (
          <div key={key}>
            <h4>{cart[key].name}</h4>
            <p>Quantity: {cart[key].quantity}</p>
            <p>Price: ${cart[key].price}</p>
          </div>
        ))}
      </div>
    );
  }
  