// components/SwipeableTabs.js
"use client";
import React, { useEffect, useRef, useState } from 'react';
import { Swiper, SwiperSlide, useSwiper } from 'swiper/react';
import SwiperCore from 'swiper';

import { Card, CardContent, CardMedia, Typography, Grid, Box, Tabs, Tab } from '@mui/material';
import { Navigation, Pagination } from 'swiper/modules';

import ProductCard from './ProductCard';
import InfiniteScroll from 'react-infinite-scroll-component';

  
// تفعيل وحدات Swiper للتنقل والترقيم
SwiperCore.use([Pagination, Navigation]);


export default function SwipeableTabButtons() {
  const [value, setValue] = useState(0);
  const [products, setProducts] = useState([]);
  const tabTitles = ["الملابس","الإلكترونيات", "الكتب",  "الألعاب", "المنزل"];
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    setCurrentPage(0);
    fetchProducts(value);  // جلب المنتجات عند تغيير التبويب
    
  }, [value]);

  const fetchProducts = async (index) => {
    const category = tabTitles[index].toLowerCase();
    try {
      const response = await fetch(`http://localhost:5187/api/Products/ByCategoryName/${category}?pageNumber=1&pageSize=10`);
      const data = await response.json();
    
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
      setProducts([]); // تفريغ المنتجات في حالة الخطأ
    }
  };
  
  const fetchMoreProducts = async () => {
    const nextPage = currentPage + 1;
    const category = tabTitles[value].toLowerCase();
    try {
      const response = await fetch(`http://localhost:5187/api/Products/ByCategoryName/${category}?pageNumber=${nextPage}&pageSize=10`);
      const data = await response.json();
      setProducts([...products, ...data]);
      setCurrentPage(nextPage);
    } catch (error) {
      console.error('Error fetching more products:', error);
    }
  };

  const handleChange = (event, newValue) => {
    console.log(newValue);
    setCurrentPage(0);

    setValue(newValue);  // تحديث القيمة
  };
  const handleScroll = (event) => {
    const { scrollTop, clientHeight, scrollHeight } = event.currentTarget;
    const isNearBottom = scrollTop + clientHeight >= scrollHeight / 2;
  
    // التحقق من أنه لا يزال هناك المزيد من المنتجات وأن المستخدم قريب من القاع
    if (isNearBottom && products.length % 2 === 0) {
     
      fetchMoreProducts();
    }
  };
  
  return (
    <Box sx={{ width: '100%' }}
  
    >
      <Tabs
        value={value}
        onChange={handleChange}
        indicatorColor="primary"
        textColor="primary"
        variant="fullWidth"
      >
        {tabTitles.map((title, index) => (
          <Tab key={index} label={title} />
        ))}
      </Tabs>
      <Swiper
        onSlideChange={(swiper) => {
          const newIndex = swiper.activeIndex;
          console.log(newIndex);
          setValue(newIndex);
          fetchProducts(newIndex);
        }}
        slidesPerView={1}
        pagination={{ clickable: false }}
        navigation={false}
      >
        {tabTitles.map((title, index) => (
          
          <SwiperSlide key={index}>
          

            <InfiniteScroll
              dataLength={products.length}
              
              next={fetchMoreProducts}
              hasMore={true}
              loader={null}
              endMessage={<p>No more products</p>}
            >
              <Grid container rowSpacing={1} justifyContent="center" alignItems="center" columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                {products.length > 0 ? (
                  products.map((product, idx) => (
                    <Grid item key={idx} xs={12} sm={6} md={4} lg={3} style={{ flex: '0 0 auto' }}>
                      <ProductCard product={product} />
                    </Grid>
                  ))
                ) : (
                  <Grid item xs={12}>
                    <Typography variant="body1" color="textSecondary">
                      لا توجد منتجات في هذا القسم حاليًا.
                    </Typography>
                  </Grid>
                )}
              </Grid>
            </InfiniteScroll>
          </SwiperSlide>
        ))}
      </Swiper>
    </Box>
  );
}