// تعريف نوع البيانات لمنتج
export interface Product {
    id: number;
    title: string;
    price: number;
    description: string;
    category: string;
    image: string;
    handle:string;
    rating: {
      rate: number;
      count: number;
    };
  }
  
  // تعريف نوع البيانات للخصائص المرسلة إلى المكون HomePage
  export interface HomePageProps {
    products: Product[];
  }
  